from django.contrib import admin
from . import models
admin.site.register([models.Doner, ])
# Register your models here.

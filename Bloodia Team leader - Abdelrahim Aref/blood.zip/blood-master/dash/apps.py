from django.apps import AppConfig


class DashConfig(AppConfig):
    name = 'dash'
